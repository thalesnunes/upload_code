Copyright (c) Axel Dahlberg. Distributed under the same terms as Vim itself. See `:help license`.
