vim.o.runtimepath = vim.o.runtimepath .. ',./rtps/plenary.nvim'
vim.cmd('runtime! plugin/plenary.vim')
